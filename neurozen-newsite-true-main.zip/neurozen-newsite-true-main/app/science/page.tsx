import type { Metadata } from 'next';
import ContentPage from '@/components/ContentPage';
import content from '@/content/science';

export const metadata: Metadata = {
  "title": "מחקרים ומקרים קליניים",
  "description": "מחקרים על דיקור חשמלי, גירוי אוזני של עצב הוואגוס ובריאות הנפש: הממצאים, מגבלות הראיות והקשר למעקב בקליניקת NeuroZen.",
  "alternates": {
    "canonical": "/science"
  },
  "openGraph": {
    "title": "מחקרים ומקרים קליניים",
    "description": "מחקרים על דיקור חשמלי, גירוי אוזני של עצב הוואגוס ובריאות הנפש: הממצאים, מגבלות הראיות והקשר למעקב בקליניקת NeuroZen.",
    "type": "website",
    "locale": "he_IL",
    "url": "/science"
  }
};

export default function Page() { return <ContentPage content={content} sectionIds={['reading', 'clinical', 'neuropuncture-evidence', 'auricular', 'bdnf', 'clinic', 'israel-ptsd', 'contact']} />; }
